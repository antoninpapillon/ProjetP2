import "./index.html";
import * as React from "react";
import * as ReactDom from "react-dom";
import {Profile} from "./profile";

interface MenuProps {
	
}

class MenuState {
	constructor(props:MenuProps) {
		
	}
	user:Profile = undefined;
}

export class Menu extends React.Component<MenuProps, MenuState> {
	constructor (props:MenuProps) {
		super(props);
		this.state = new MenuState(props);
	}
	
	buildMenu (access:string) {
		switch (access) {
			case "view":
				return (
					<nav>
						<ul className="desktop">
							<li><a href="">Visualiser</a></li>
						</ul>
						<ul className="small">
							<li><a href="">V</a></li>
						</ul>
					</nav>
				)
			case "edit":
				return (
					<nav>
						<ul className="desktop">
							<li><a href="">Saisir</a></li>
						</ul>
						<ul className="small">
							<li><a href="">S</a></li>
						</ul>
					</nav>
				)
			case "both":
				return (
					<nav>
						<ul className="desktop">
							<li><a href="">Visualiser</a></li>
							<li><a href="">Saisir</a></li>
						</ul>
						<ul className="small">
							<li><a href="">V</a></li>
							<li><a href="">S</a></li>
						</ul>
					</nav>
				)
			default:
				return (
					<nav>
					</nav>
				)
		}
	}
	
	render () {
		var result:any;
		if (this.state.user != undefined) {
			result = this.buildMenu(this.state.user.access);
		}
		else {
			// window.location.replace("https://www.google.fr");
		}
		return (
			<div key="access">
			{
				result
			}
			</div>
		)
	}
}

ReactDom.render(<Menu/>, document.getElementById("menu"));