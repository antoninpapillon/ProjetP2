export class Profile {
	id:number;
	login:string;
	password:string;
	role:string;
	access:string;
}