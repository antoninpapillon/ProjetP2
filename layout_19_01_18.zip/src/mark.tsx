import {Control} from "./control";

export class Mark extends Control {
	value:number;
	
	constructor(code:string, coefficient:number, is_module:boolean, label:string, module:string, optional:boolean, teacher:string, type:string, value:number) {
		super(code, coefficient, is_module, label, module, optional, teacher, type);
		this.value = value;
	}
}