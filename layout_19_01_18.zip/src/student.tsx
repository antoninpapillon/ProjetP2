import {Profile} from "./profile";

export class Student extends Profile {
	has_lv2:boolean;
	has_bonus:boolean;
	has_sandwichCourse:boolean;
}