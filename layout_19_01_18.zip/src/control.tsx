export class Control {
	code:string;
	coefficient:number;
	is_module:boolean;
	label:string;
	module:string;
	optional:boolean;
	teacher:string; // or number depending on JSON teacher structure
	type:string;
	
	constructor (code:string, coefficient:number, is_module:boolean, label:string, module:string, optional:boolean, teacher:string, type:string) {
		this.code = code;
		this.coefficient = coefficient;
		this.is_module = is_module;
		this.label = label;
		this.module = module;
		this.optional = optional;
		this.teacher = teacher;
		this.type = type;
	}
}