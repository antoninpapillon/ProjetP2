import * as React from "react";
import {Mark} from "./mark";
import {DisplayAverage} from "./display_average";

interface DisplayGridProps {
	mark:Mark;
	marks:Mark[];
}

class DisplayGridState {
	constructor (props:DisplayGridProps) {
		
	}
}

export class DisplayGrid extends React.Component<DisplayGridProps, DisplayGridState> {
	constructor (props:DisplayGridProps) {
		super(props);
		this.state = new DisplayGridState(props);
	}
	
	// Change la classe de la ligne dans le tableau selon qu'elle contient un module ou une épreuve
	assignClassName (is_module:boolean) {
		return !is_module ? "test" : "module";
	}
	
	// Différent retour selon la nature de la ligne (module ou épreuve)
	displayMark (mark:Mark, marks:Mark[]) {
		if (!mark.is_module) {
			// Si la ligne contient une épreuve, on affiche la note simplement
			return (
				<DisplayAverage marks={[mark]} key={mark.code}/>
			)
		}
		else {
			// Création d'un tableau contenant toutes les notes appartenant au module spécifié
			var module_marks = marks.filter(m => m.module == mark.module),
				indexMark = module_marks.findIndex((m)=>{ return m == mark; })
			// Suppresion de l'entête de module du tableau créé (on n'utilise que les épreuves pour calculer la moyenne)
			if (indexMark >= 0) {
				module_marks.splice(indexMark, 1);
			}
			// Calcul de la moyenne du module
			return (
				<DisplayAverage marks={module_marks} key={mark.code}/>
			)
		}
	}
	
	// Si la note est de type xx,x0, on supprime le dernier zéro (afficher 18,5 au lieu de 18,50)
	formatMark (value:string) {
		return value.substring(value.length - 1) == "0" ? value.substring(0, value.length - 1) : value;
	}
	
	render () {
		// Affichage de la ligne, en convertissant les chiffres en chaîne de caractère pour remplacer les "." par des "," (18,5 au lieu de 18.5)
		return (
			<tr className={this.assignClassName(this.props.mark.is_module)}>
				<td>{this.props.mark.label}</td>
				<td>{this.props.mark.coefficient.toString().replace(".", ",")}</td>
				<td>{this.displayMark(this.props.mark,this.props.marks)}</td>
			</tr>
		)
	}
}