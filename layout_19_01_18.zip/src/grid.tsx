import "./index.html";
import * as React from "react";
import * as ReactDom from "react-dom";
import {DisplayGrid} from "./display_grid";
import {DisplayAverage} from "./display_average";
import {Profile} from "./profile";
import {Mark} from "./mark";

interface GridProps {
	
}

class GridState {
	constructor (props:GridProps) {
		
	}
	marks:Mark[] = [];
}

export class Grid extends React.Component<GridProps, GridState> {
	constructor (props:GridProps) {
		super(props);
		this.state = new GridState(props);
	}
	
	// Chargement des données en dur pour le moment, les données JSON seront importées d'ici ultérieurement
	componentDidMount () {
		this.setState({
			marks:[({
				code:"info",
				coefficient:3,
				is_module:true,
				label:"Infocom",
				module:"Infocom",
				optional:false,
				teacher:"",
				type:"Pratique",
				value:0
			}),({
				code:"test",
				coefficient:6.5,
				is_module:false,
				label:"Programmation",
				module:"Infocom",
				optional:false,
				teacher:"",
				type:"Pratique",
				value:18.5096
			}),({
				code:"retest",
				coefficient:4,
				is_module:false,
				label:"Communication",
				module:"Infocom",
				optional:false,
				teacher:"",
				type:"Théorique",
				value:8
			}),({
				code:"mod",
				coefficient:4,
				is_module:true,
				label:"Langues",
				module:"Langues",
				optional:false,
				teacher:"",
				type:"Théorique",
				value:8
			}),({
				code:"zbl",
				coefficient:2,
				is_module:false,
				label:"Anglais",
				module:"Langues",
				optional:false,
				teacher:"",
				type:"Théorique",
				value:7.9999
			})]
		});
	}
	
	render () {
		return (
			<div>
				<div>
					<img src="" alt=""/>
					<h2>Tests</h2>
				</div>
				<div>
					<table>
						<thead>
							<tr>
								<th>Intitulé</th>
								<th>Coefficient</th>
								<th>Note</th>
							</tr>
						</thead>
						<tbody>
						{
							this.state.marks && this.state.marks.map((mark)=>{
								// Pour chaque note dans la liste de notes, ajout d'une ligne dans la grille avec les valeurs de la note
								return (
									<DisplayGrid mark={mark} marks={this.state.marks} key={mark.code}/>
								)
							})
						}
						</tbody>
					</table>
					<div className="moy">
						<p>Moyenne générale</p>
						<DisplayAverage marks={this.state.marks} key="average"/>
					</div>
				</div>
			</div>
		)
	}
}

// Intégration de la grille dans la section d'id #grid
ReactDom.render(<Grid/>, document.getElementById("grid"));